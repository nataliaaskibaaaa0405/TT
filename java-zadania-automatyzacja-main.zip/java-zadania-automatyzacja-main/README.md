# Automatyzacja: rozwiązania zadań 1–6

Projekt Groovy dla **JDK 25 i Maven**, gotowy do otwarcia w IntelliJ IDEA. Zadania 2–6 to uruchamialne skrypty z gotowymi argumentami. Zadanie 1 dotyczy Jenkinsa i ma osobny `zadanie01/Jenkinsfile`.

## Uruchomienie w IntelliJ

1. Wybierz **File → Open**, wskaż plik `pom.xml` w tym katalogu i otwórz go jako projekt. Jeżeli katalog był już otwarty w IDE, zamknij ten projekt przed ponownym importem.
2. W **File → Project Structure → Project** ustaw **Project SDK: JDK 25** i **Language level: SDK default**. Jeśli JDK 25 nie ma na liście, użyj **Add SDK → Download JDK** i wybierz wersję 25.
3. W **Settings → Build, Execution, Deployment → Build Tools → Maven** wybierz **Maven home path: Use Maven wrapper**. W podsekcji **Importing** ustaw **JDK for importer: Project JDK (25)**, a w **Runner** ustaw **JRE: Project JDK (25)**.
4. Włącz wtyczki **Groovy** i **Maven**, jeśli są wyłączone. W oknie Maven wybierz **Reload All Maven Projects** i poczekaj na pobranie zależności. Nie trzeba instalować osobno Maven ani Groovy; pierwsze uruchomienie wymaga internetu.
5. Z listy konfiguracji uruchomienia wybierz np. **Zadanie 4 - Srednia** i kliknij **Run**. Konfiguracja **Zadania 2-6 - Wszystkie** uruchamia kolejno wszystkie lokalne przykłady. Konfiguracje Maven są zapisane w `.run/` i korzystają z JDK projektu.

Każdy plik `Main.groovy` jest w osobnym pakiecie (`zadanie02` itd.), dzięki czemu nazwy klas nie kolidują. Gotowe konfiguracje najpierw kompilują źródła, a następnie uruchamiają zadania w osobnych procesach Javy. Katalogiem roboczym jest katalog projektu.

## Zawartość

| Zadanie | Rozwiązanie | Domyślne argumenty / wynik |
| --- | --- | --- |
| 1. Jenkins i prywatne repozytorium | `zadanie01/Jenkinsfile` | Checkout przez SSH; wymaga własnego repozytorium i poświadczeń w Jenkinsie |
| 2. Zmienne i argumenty | `src/main/groovy/zadanie02/Main.groovy` | `Ala Groovy`; wartości zmiennych i oba argumenty |
| 3. Pętle i argumenty | `src/main/groovy/zadanie03/Main.groovy` | `10 20 30`; wynik `10, 20, 30` uzyskany pętlą oraz przez `join` |
| 4. Średnia | `src/main/groovy/zadanie04/Main.groovy` | `7.5 12.5`; średnia `10.0` |
| 5. Silnia | `src/main/groovy/zadanie05/Main.groovy` | `0 5 10`; wyniki `1`, `120`, `3628800` |
| 6. Pliki | `src/main/groovy/zadanie06/Main.groovy` | `oba`; odczyt i dopisanie do `dane/example.txt` |

## Zmiana argumentów

W **Run → Edit Configurations** wybierz konfigurację Maven danego zadania i w polu **Run** dodaj właściwość `-DzadanieN.args`, np.:

<pre><code>compile exec:exec@zadanie4 "-Dzadanie4.args=8 12"</code></pre>

Domyślne argumenty wszystkich zadań znajdują się w sekcji `properties` w `pom.xml`: `zadanie2.args`, `zadanie3.args` itd.

Z terminala PowerShell, otwartego w katalogu projektu:

<pre><code>.\mvnw.cmd compile exec:exec@zadanie2
.\mvnw.cmd compile exec:exec@zadanie3 "-Dzadanie3.args=1 2 3 4"
.\mvnw.cmd compile exec:exec@zadanie4 "-Dzadanie4.args=8 12"
.\mvnw.cmd compile exec:exec@zadanie5 "-Dzadanie5.args=0 5 21"
.\mvnw.cmd compile exec:exec@zadanie6
.\mvnw.cmd compile exec:exec@zadanie2 exec:exec@zadanie3 exec:exec@zadanie4 exec:exec@zadanie5 exec:exec@zadanie6</code></pre>

Sama kompilacja i przygotowanie pliku JAR (bez wykonywania zadań):

<pre><code>.\mvnw.cmd clean package</code></pre>

W macOS/Linux użyj `./mvnw` zamiast `.\mvnw.cmd`; jeśli potrzeba, nadaj mu prawo wykonania przez `chmod +x mvnw`. Wrapper korzysta z `JAVA_HOME` lub Javy dostępnej w `PATH`. Ustawienia SDK w IntelliJ nie zmieniają automatycznie Javy w terminalu. Polecenie `.\mvnw.cmd -version` powinno pokazać **Java version: 25...**. W razie innej wersji ustaw `JAVA_HOME` na katalog swojego JDK 25 i ponownie otwórz terminal.

Projekt sprawdza wersję Javy na początku budowania i wymaga JDK 25. Kod Groovy jest kompilowany do bytecode dla Javy 25.

## Zadanie 6: tryby pracy

* `odczyt` wyświetla istniejący plik i nie zmienia jego zawartości. Przy braku pliku zgłasza błąd.
* `dopisz` dopisuje tekst i pokazuje zawartość po zmianie.
* `oba` pokazuje zawartość przed i po dopisaniu.

Drugi argument to opcjonalna ścieżka pliku, a trzeci to tekst do dopisania. Domyślnie są to `dane/example.txt` i `Dodatkowa linia tekstu.`. Przykład w terminalu IntelliJ (PowerShell):

<pre><code>.\mvnw.cmd compile exec:exec@zadanie6 "-Dzadanie6.args=oba dane/notatki.txt 'Moja dodatkowa linia.'"
.\mvnw.cmd compile exec:exec@zadanie6 "-Dzadanie6.args=odczyt dane/notatki.txt"</code></pre>

W trybach `dopisz` i `oba` brakujący plik zostanie utworzony z tekstem `Pierwsza linia pliku.`, a następnie rozszerzony. Kolejne uruchomienia dopisują następne linie. Pliki robocze trafiają domyślnie do ignorowanego katalogu `dane/`.

## Zadanie 1: uruchomienie w Jenkinsie

1. Przygotuj prywatne repozytorium GitHub z gałęzią, którą chcesz pobierać, i klucz SSH mający do niego dostęp. Jeżeli korzystasz z repozytorium z wcześniejszego tematu, sprawdź jego widoczność w ustawieniach GitHub.
2. W Jenkinsie dodaj poświadczenie **SSH Username with private key**, z użytkownikiem `git` i identyfikatorem `github-ssh`. Umieść w nim klucz prywatny odpowiadający kluczowi publicznemu dopuszczonemu do repozytorium. Klucze przechowuj w Jenkins Credentials.
3. Na agencie Jenkinsa musi być dostępny Git, a Jenkins powinien mieć skonfigurowaną weryfikację klucza hosta GitHub. Potrzebne są wtyczki Pipeline i Git.
4. W pliku `zadanie01/Jenkinsfile`, w bloku `environment`, wpisz własny adres SSH jako `REPO_URL`. Dostosuj `REPO_BRANCH` i `GITHUB_CREDENTIALS_ID`, jeśli używasz innej gałęzi lub innego identyfikatora poświadczeń.
5. Utwórz zadanie typu **Pipeline**, wybierz **Pipeline script**, wklej uzupełniony `Jenkinsfile`, zapisz konfigurację i kliknij **Build Now**.
6. Po poprawnym pobraniu repozytorium wynik powinien być `SUCCESS`. Zapisany w skrypcie `pollSCM` sprawdza zmiany co około pięć minut i uruchamia zadanie po wykryciu nowego commitu. Wymaga wcześniejszego udanego pobrania repozytorium.

`Jenkinsfile` wykonuje środowisko Jenkinsa; nie jest lokalnym skryptem `Main.groovy`. Projekt nie zawiera kluczy ani poświadczeń do prywatnego repozytorium.

## Wersje i dokumentacja

Projekt używa **JDK 25**, **Groovy 4.0.33** i **Maven 3.9.16**. GMavenPlus 4.3.1 kompiluje Groovy do wersji bytecode 25; Exec Maven Plugin 3.6.4 uruchamia zadania. Maven Wrapper 3.3.4 pobiera Maven, którego suma SHA-256 jest zapisana w `.mvn/wrapper/maven-wrapper.properties`.

* [Obsługa Groovy w IntelliJ](https://www.jetbrains.com/help/idea/groovy.html)
* [Konfiguracje uruchomienia Maven w IntelliJ](https://www.jetbrains.com/help/idea/run-debug-configuration-maven.html)
* [Maven Wrapper](https://maven.apache.org/tools/wrapper/)
* [Kompilacja Groovy i obsługiwane wersje bytecode](https://groovy.github.io/GMavenPlus/compile-mojo.html)
* [Uruchamianie programów przez Exec Maven Plugin](https://www.mojohaus.org/exec-maven-plugin/examples/example-exec-for-java-programs.html)
* [Pobieranie repozytorium w Jenkinsie](https://www.jenkins.io/doc/pipeline/steps/git/)
