package zadanie02

// Zadanie 2: zmienne różnych typów i argumenty skryptu.
def liczba = 1
float fLiczba = 7.1f
double dLiczba = 5.2d
def bZmienna = true
def tekst = 'Jakiś tekst'
def tekstO = new String('Inny tekst')

println "liczba = ${liczba}"
println "fLiczba = ${fLiczba}"
println "dLiczba = ${dLiczba}"
println "bZmienna = ${bZmienna}"
println "Tu mamy ${tekst}, a tu jest ${tekstO}"

if (args.length == 2) {
    println "Pierwszy argument: ${args[0]}"
    println "Drugi argument: ${args[1]}"
} else {
    println 'Aby wyświetlić argumenty, podaj dokładnie dwa, np. Ala Groovy.'
}
