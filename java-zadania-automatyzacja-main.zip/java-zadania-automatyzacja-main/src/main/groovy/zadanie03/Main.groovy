package zadanie03

// Zadanie 3: dwa sposoby wypisania argumentów oddzielonych przecinkami.
if (args.length == 0) {
    System.err.println 'Podaj przynajmniej jeden argument, np. 10 20 30.'
    System.exit(1)
}

def wynik = ''
args.eachWithIndex { arg, i ->
    wynik += arg
    if (i < args.length - 1) {
        wynik += ', '
    }
}

println "Pętla: ${wynik}"
println "join: ${args.join(', ')}"
