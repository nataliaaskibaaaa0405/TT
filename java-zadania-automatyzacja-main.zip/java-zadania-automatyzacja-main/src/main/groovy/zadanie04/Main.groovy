package zadanie04

// Zadanie 4: średnia arytmetyczna dokładnie dwóch liczb.
if (args.length != 2) {
    System.err.println 'Podaj dokładnie dwie liczby jako argumenty, np. 7.5 12.5.'
    System.exit(1)
}

try {
    double liczba1 = args[0].toDouble()
    double liczba2 = args[1].toDouble()

    if (!Double.isFinite(liczba1) || !Double.isFinite(liczba2)) {
        throw new NumberFormatException('Liczby muszą być skończone.')
    }

    double srednia = (liczba1 + liczba2) / 2
    println "Średnia podanych liczb to: ${srednia}"
} catch (NumberFormatException ignored) {
    System.err.println 'Podano nieprawidłowe dane. Podaj dwie skończone liczby; użyj kropki dziesiętnej.'
    System.exit(1)
}
