package zadanie06

// Zadanie 6 z rozszerzeniem: tryb, ścieżka pliku i dopisywany tekst.
// Przykład argumentów w IntelliJ: oba dane/example.txt "Moja dodatkowa linia."
def tryb = args.length > 0 ? args[0] : 'oba'
def sciezka = args.length > 1 ? args[1] : 'dane/example.txt'
def nowaTresc = args.length > 2 ? args[2] : 'Dodatkowa linia tekstu.'

if (args.length > 3 || !(tryb in ['odczyt', 'dopisz', 'oba'])) {
    System.err.println 'Użycie: odczyt|dopisz|oba [ścieżka] ["tekst do dopisania"]'
    System.exit(1)
}

def plik = new File(sciezka)
try {
    if (!plik.exists()) {
        if (tryb == 'odczyt') {
            System.err.println "Plik nie istnieje: ${plik.absolutePath}"
            System.exit(1)
        }

        def katalog = plik.absoluteFile.parentFile
        if (!katalog.exists() && !katalog.mkdirs()) {
            throw new IOException("Nie można utworzyć katalogu: ${katalog}")
        }
        plik.setText('Pierwsza linia pliku.', 'UTF-8')
        println "Utworzono plik: ${plik.absolutePath}"
    }

    if (!plik.isFile()) {
        throw new IOException("Podana ścieżka nie jest plikiem: ${plik.absolutePath}")
    }

    if (tryb in ['odczyt', 'oba']) {
        println 'Zawartość pliku:'
        println plik.getText('UTF-8')
    }

    if (tryb in ['dopisz', 'oba']) {
        plik.append("\n${nowaTresc}", 'UTF-8')
        println 'Nowa zawartość została dodana.'
        println 'Zawartość po dopisaniu:'
        println plik.getText('UTF-8')
    }
} catch (IOException problem) {
    System.err.println "Błąd obsługi pliku: ${problem.message}"
    System.exit(1)
}
