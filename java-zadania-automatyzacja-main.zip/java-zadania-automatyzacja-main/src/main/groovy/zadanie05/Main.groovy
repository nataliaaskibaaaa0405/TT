package zadanie05

// Zadanie 5: funkcja obliczająca silnię, także 0! = 1.
// BigInteger pozwala obliczyć np. 21! bez przepełnienia typu long.
BigInteger silnia(int n) {
    if (n < 0) {
        throw new IllegalArgumentException('Silnia jest określona dla liczb całkowitych nieujemnych.')
    }

    BigInteger wynik = 1G
    for (int i = 2; i <= n; i++) {
        wynik *= i
    }
    return wynik
}

if (args.length == 0) {
    System.err.println 'Podaj przynajmniej jedną nieujemną liczbę całkowitą, np. 0 5 10.'
    System.exit(1)
}

def wystapilBlad = false
args.each { arg ->
    try {
        int liczba = arg.toInteger()
        println "Silnia liczby ${liczba} to: ${silnia(liczba)}"
    } catch (NumberFormatException ignored) {
        System.err.println "Argument '${arg}' nie jest prawidłową liczbą całkowitą typu int."
        wystapilBlad = true
    } catch (IllegalArgumentException problem) {
        System.err.println "Argument '${arg}': ${problem.message}"
        wystapilBlad = true
    }
}

if (wystapilBlad) {
    System.exit(1)
}
